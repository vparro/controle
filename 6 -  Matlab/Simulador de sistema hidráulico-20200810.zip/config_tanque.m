% Script para carregar constantes de simula??o da planta de n?vel
% Autor: Rodrigo Alvite Romano
% Data: Mar/2015

A = 1.32;               % [m2] ?rea do tanque
k1 = (0.2323e-2)*99.0285;  % k1 = kv*sqrt(\rho*g)
hbar = 6.5;             % [m] N?vel no ponto de opera??o

% Vaz?o de entrada para equil?brio no ponto de opera??o
qebar = k1*sqrt(hbar);
% Amplitude do pulso
delta = 1*qebar;

sim('sim_tanque.slx');
close all;
plot(t,h,t,hlinear,'r--','Linewidth',1.5)
grid on
xlabel('Tempo')
ylabel('N�vel')
legend('n�o-linear','linear',4)

