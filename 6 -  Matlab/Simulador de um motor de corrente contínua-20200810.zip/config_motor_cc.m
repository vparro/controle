% Constantes do motor

L = .5e-3;
R = 2.47;

Kv = 6.73e-2;
Kt = Kv;

b = 1.8e-3;
Fc = 0.02;
J = 1.1e-5 + 4e-4;